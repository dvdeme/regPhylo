#' Sequences and metadata extracted from the Barcode of Life Database (BOLD), GenBank (NCBI) and the repository of the New Zealand National 
#' Fish collection for the species "Diastobranchus capensis".
#' 
#' This example provides a list of tables storing sequences and metadata for the species "Diastobranchus capensis". 
#' Each table correspond to the output table of the following functions: GetSeq_BOLD, GetSeqInfo_NCBI.taxid, 
#' Congr.NCBI.BOLD.perReposit, GeoCoord.WGS84, GeoCodeName.
#' @format a list of 6 tables: 
#' 1) This table contains the raw output (sequences and metadata extracted from the Barcode of Life Database (BOLD) 
#' for the species "Diastobranchus capensis" the 9/10/2018) of the function GetSeq_BOLD from the regPhylo package.
#' @format The table "Seq.BOLD" is A data frame with 8 rows and 82 columns
#' 2) This table contains the raw output (sequences and metadata extracted from GenBank (NCBI) 
#' for the species "Diastobranchus capensis" the 9/10/2018) of the function GetSeqInfo_NCBI.taxid from the regPhylo package
#' @format The table "Seq.NCBI" is a data frame with 4 rows and 23 columns
#' 3) This table contains 1 DNA sequence and the associated metadata present in the repository of 
#' the New Zealand National fish collection store at the National Museum of New Zealand, Te Papa Tongarewa.
#' @format The table "Seq.Perso" is a data frame with 1 row and 24 columns
#' 4) This table contains the raw output of the function Congr.NCBI.BOLD.perReposit including data 
#' coming from NCBI, BOLD, and a personal repository, for the species "Diastobranchus capensis".
#' @format The table "Seq.DF" is a data frame with 11 rows and 25 columns.
#' 5) This table contains the raw output of the function GeoCoord.WGS84 which splits the Lat_Lon field in two distinct fields "Latitude" and "Longitude" and convert all the geographic coordinates in WGS84 #' decimal degrees using +- North, and +- East (i.e. -45.10, -53.23).
#' @format The table "Seq.DF1" is a data frame with 11 rows and 26 columns
#' 6) This table contains the raw output of the function GeoCodeName which extract the geographic coordinates from nominatim openstreetmap API for all the sequences with only place name information.
#' The table provide two additional columns one providing the place name used for the query, and another column providing information about the precision of the geographic coordinates.
#' @format The table "Seq.DF3" is a data frame with 11 rows and 28 columns
"Seq.Diastocapen" 

#'



#' Sequences and metadata extracted from the Barcode of Life Database (BOLD) for the species "Diastobranchus capensis" the 9/10/2018
#'  
#' This table contains the raw output of the function GetSeq_BOLD from the regPhylo package
#' @format A data frame with 8 rows and 82 columns
"Seq.BOLD"


#' Sequences and metadata extracted from GenBank (NCBI) for the species "Diastobranchus capensis" the 9/10/2018
#'  
#' This table contains the raw output of the function GetSeqInfo_NCBI.taxid from the regPhylo package
#' @format A data frame with 4 rows and 23 columns
"Seq.NCBI"


#' Sequences and metadata from the repository of the New Zealand National Fish collection for the species "Diastobranchus capensis".
#'  
#' This table contains 1 DNA sequence and the associated metadata present the repository of the New Zealand National fish collection store at  the National Museum of New Zealand, Te Papa Tongarewa
#' @format A data frame with 1 row and 24 columns
"Seq.Perso"


#' Sequences and metadata exported by the Congr.NCBI.BOLD.perReposit function for the species "Diastobranchus capensis"
#' 
#' This table contains the raw output of the function Congr.NCBI.BOLD.perReposit including data coming from NCBI, BOLD, and a personal repository, for the species "Diastobranchus capensis".
#' @format A data frame with 11 rows and 25 columns
"Seq.DF"


#' Sequences and metadata exported by the GeoCoord.WGS84 function for the species "Diastobranchus capensis"
#' 
#' This table contains the raw output of the function GeoCoord.WGS84 which splits the Lat_Lon field in two distinct fields "Latitude" and "Longitude" and convert all the geographic coordinates in WGS84 #' #' decimal degrees using +- North, and +- East (i.e. -45.10, -53.23)
#' @format A data frame with 11 rows and 26 columns
"Seq.DF1"


#' Sequences and metadata exported by the GeoCodeName function for the species "Diastobranchus capensis"
#'
#' This table contains the raw output of the function GeoCodeName which extract the geographic coordinates from nominatim openstreetmap API for all the sequences with only place name information.
#' The table provide two additional columns one providing the place name used for the query, and another column providing information about the precision of the geographic coordinates.
#' @format A data frame with 11 rows and 28 columns
"Seq.DF3"


#' Output of the function SpeciesGeneMat.Bl and Select.DNA for the species "Diastobranchus capensis"
#' 
#' This output is a list of 6 objects: the first five element are the output of the SpeciesGeneMat.Bl function, the sixth object is the table output of the Select.DNA function.
#' The first table provides the species-by-gene matrix, the second table provides a summary table from a gene perspective (number of species and sequences for each gene region), and the third table provides a summary tables from the species perspective (number of gene regions and sequences for each species), the fourth object provides an empty string listing the species lost when removing microsatellites, unassigned DNA, or blacklisted sequences, the fifth element is a table including all the sequences and the metadata exported by the function SpeciesGeneMat.Bl after removing microsatellites, unassigned DNA and potentially blacklisted sequences. This table also includes two additional columns, one reporting the entry order of the sequences, and the other the name of the gene region used for the species-by-gene matrix.
#' Finally the last table (i.e. "Seq.DF5") ouptut of the 
#' @format A list of 5 data frames and one string, 
#' 1) The first table provides the species-by-gene matrix
#' @format a data frame with 1 row and 4 columns.
#' 2) the second table provides a summary table from a gene perspective (number of species and sequences for each gene region).
#' @format a data frame with 3 rows and 3 columns
#' 3) the third table provides a summary tables from the species perspective (number of gene regions and sequences for each species).
#' @format a data frame has 1 row and 3 columns
#' 4) The fourth object provides an empty string listing the species lost when removing microsatellites, unassigned DNA, or blacklisted sequences
#' @format a empty string.
#' 5) the fourth table (i.e. "Seq.DF4.dataTable") provides all the sequences and the metadata exported by the function SpeciesGeneMat.Bl after removing microsatellites, unassigned DNA and potentially blacklisted sequences.
#' @format a data frame with 1 rows and 30 columns
#' 6) This data frame includes all the seqeunces and metadata exported for selected gene regions, ane also extract from GenBank all sequences longer than 5000bp, that might belong to full mitochondrial genome, and import the gene region of interest listed in the selection of gene regions.
#' @format a data frame with 11 rows and 29 columns (the columns with the entry order of the sequences has been removed)
"Seq.DF4"


#' Output table storing the sequences and the metadata exported by the SpeciesGeneMat.Bl function for the species "Diastobranchus capensis"
#' 
#' This data table includes all the sequences and the metadata exported by the function SpeciesGeneMat.Bl after removing microsatellites, unasigned DNA and potentially blacklisted sequences.
#' The table also includes two additional columns, one reporting the entry order of the sequences, and the other the name of the gene region used for the species-by-gene matrix.
#' @format A data frame with 11 rows and 30 columns
"Seq.DF4.dataTable"


#' Output table of the sequences and metadata exported from the Select.DNA function of the species "Diastobranchus capensis"
#' 
#' This data frame includes all the seqeunces and metadata exported for selected gene regions, ane also extract from GenBank all sequences longer than 5000bp, that might belong to full mitochondrial genome, and import the gene region of interest listed in the selection of gene regions. 
#' @format A data frame with 11 rows and 29 columns (the columns with the entry order of the sequences has been removed)
"Seq.DF5"


#' Example of an alignment including 319 sequences of 16S mitochondrial DNA, and a table of potential outlier sequences detected by the Detect.Outlier.Seq function.
#' 
#' 
#' The aim of this example is to illustrate the use of Detect.Outlier.Seq and Rm.OutSeq.Gap functions. The .Rdata object is a list of two objects, 
#' the first is "alignment" of 319 sequences of 16S mitochondrial DNA, the second object is "Table.Outlier.Seq.16S" is a list of primary and secondary 
#' potential outlier sequences detected using the Detect.Outlier.Seq function, based on the the following settings:
#' Table.Outlier.Seq.16S = Detect.Outlier.Seq(inputal = Example_16S_outlier, Strat.DistMat = "Comb", Dist.Th = 0.6, output = "Example_16S_outliers_2.txt", Second.Outlier = "Yes", Bitsc.Th = 0.8)
#' @format A list of two objects 1) an object of class "alignment" including a list of 319 DNA sequences of 16S mitochondrial DNA called "16S_example_outliers.fas", 
#' @format 2) A table with 85 rows and 16 columns called "Table.Outlier.Seq.16S".
"Example_16S_outlier"


#' A list of two tables: a table listing the topological constraints to build a multifurcating tree, and a classification table, for the example of 16 species of NZ fish.
#'
#'
#' This list contains two tables: the first table, the constraint table, is a two column table, the first column refers to the hierarchical
#' level of the topological constraints (e.g.= 'Family', or 'Order', or 'Subdivision'...), and the second column refers to the name of the hierarchy (i.e. Aplodactylidae, Anguilliformes), the second table, the classification table, is a multicolumns table, the first column provides the species names (or the name used as tip.label by the phylogenetic tree), then the following columns are the different hierarchical levels of the Linnean classification.
#' @format A list of 2 tables: the first table has 22 rows and 2 columns, the second table has 16 rows and 23 columns.
"TopoConstraints"






















