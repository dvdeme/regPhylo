library(testthat)
library(regPhylo)

test_check("regPhylo")
